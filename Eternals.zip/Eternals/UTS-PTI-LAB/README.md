# UTS-PTI LAB

Idle Clicker Game

Kelompok Eternals :
Hosea (00000070562)
Christopher Mesaya (00000070524)
Benedick Christopher Bamba (00000071174)
Prajna Ananda Citra (00000070561)

Direkomendasikan menggunakan extension live server di aplikasi Visual Studio Code dalam membuka codenya.

Link Github: https://github.com/hosea304/UTS-PTI-LAB

Aturan Permainan:

1. Pada awal game tidak ada penambahan score secara otomatis, pemain harus melakukan klik pada karakter secara manual untuk menambahkan score.
2. Ketika pemain sudah mempunyai cukup score untuk membeli item, maka pemain bisa membeli item-item untuk menambah kecepatan untuk menambah score.
3. Pemain juga dapat membeli auto clicker yang memungkinkan pemain mendapatkan score yang terus bertambah tanpa pemain harus melakukan klik pada karakter secara manual.
4. Jika score tidak mencukupi untuk membeli barang, maka akan diberi peringatan, dan pemain harus mengumpulkan scorenya terlebih dahulu sampai mencapai score yang dibutuhkan.
5. Terdapat 3 button pada permainan:
   A. Basic click (terletak di atas karakter) : menambah jumlah click sebanyak 1 setiap pembelian.
   B. More clicks (terletak di sebelah kiri bawah karakter) : menambah jumlah click sebanyak 2^n di setiap pembelian.
   Keterangan : n = jumlah pembelian pada bagian more clicks.
   C. Auto click (terletak di sebelah kanan bawah karakter) : pada pembelian pertama, akan membuat pemain mendapatkan score tanpa melakukan klik secara manual. Kemudian pada pembelian selanjutnya, akan menambah jumlah click yang dilakukan secara otomatis.
6. Score yang dimiliki akan tetap tersimpan tanpa mengurangi apapun.
7. Ketika pemain melakukan klik Reset Progress, maka score yang dimiliki serta level yang sudah dikumpulkan akan ter reset/terulang kembali dari awal.
